function Register()
  return "48 89 5C 24 08 57 48 83 EC 30 48 8B D9 48 89 54 24 20 33 C9"
end

function OnMatchFound(MatchAddress)
  return MatchAddress
end
