-- Made by pleby

NotifyOnNewObject("/Script/Pal.PalWeaponBase", function(var)
	var.CoolDownTime  = 0
end)

--FYI I got no fucking clue what im doing, but aye it works.